import sqlite3

class Contact: 
    def __init__(self, db_file):
        self.connexion = sqlite3.connect(db_file)
        self.curseur = self.connexion.cursor()
        self.creer_table_contact()

   def creer_table_contact(self):
        self.curseur.execute('''CREATE TABLE IF NOT EXISTS contact (
                                id INTEGER PRIMARY KEY,
                                nom TEXT,
                                prenom TEXT,
                                adresse TEXT,
                                email TEXT,
                                tel TEXT)''')
        self.connexion.commit()
        
    def ajouter_contact(self, nom, prenom, adresse, email, tel):
        self.curseur.execute("INSERT INTO contact (nom, prenom, adresse, email, tel) VALUES (?, ?, ?, ?, ?)", (nom, prenom, adresse, email, tel))
        self.connexion.commit()    

    def afficher_contacts(self):
        self.curseur.execute("SELECT nom, prenom, email, tel FROM contact")
        contacts = self.curseur.fetchall()
        for contact in contacts:
            print(f"{contact[0]} {contact[1]} - {contact[2]} - {contact[3]}")

    def supprimer_contact(self, nom, archiver=False):   
                
     